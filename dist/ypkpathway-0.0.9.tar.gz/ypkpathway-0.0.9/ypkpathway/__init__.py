#!/usr/bin/env python
# -*- coding: utf-8 -*-

__version__ = "0.0.9"
__author__  = "Björn Johansson"
__email__   = "bjorn_johansson@bio.uminho.pt"

from ypkpathway import PathWay

