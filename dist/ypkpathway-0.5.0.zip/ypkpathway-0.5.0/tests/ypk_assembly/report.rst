=====================================================================
Yeast Pathway Kit Assembly Report
=====================================================================

Yeast pathway kit assembly 2014-12-10 04:41:42:

`pYPK0_RPL12Btp_CiGXF1_TDH3tp_PsXYL2_PGI1tp_pw <./pYPK0_RPL12Btp_CiGXF1_TDH3tp_PsXYL2_PGI1tp_pw.txt>`_
(`plan <./pYPK0_RPL12Btp_CiGXF1_TDH3tp_PsXYL2_PGI1tp_pw_plan.html>`__)

List of all `PCR primers <./primer_list.txt>`_ needed
  

`pYPK0_RPL12Btp_CiGXF1_TDH3tp <./pYPK0_RPL12Btp_CiGXF1_TDH3tp.txt>`_ (`plan <./pYPK0_RPL12Btp_CiGXF1_TDH3tp_plan.html>`__)


`pYPK0_TDH3tp_PsXYL2_PGI1tp <./pYPK0_TDH3tp_PsXYL2_PGI1tp.txt>`_ (`plan <./pYPK0_TDH3tp_PsXYL2_PGI1tp_plan.html>`__)


